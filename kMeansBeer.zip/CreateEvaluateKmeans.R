library(readr)
beer <- read_csv("beer.csv")
# use the head() function to check variables & their type
head(beer)
# make sure abv and ibu are doubles, cast with as.double() if not

# create a new scaled dataframe, beerD, with the data.frame() and scale() functions
# beerD should only include columns 1 & 2 from beer i.e. beer[,c(1,2)]
beerD<-data.frame(scale(beer[,c(1,2)]))

#create a numeric vector, wss, to keep track of the within sum of squares values
wss<-numeric(10)

# use the following line of code to assign the withinss for 1 through 10 clusters
for(i in 1:10){wss[i]<-sum(kmeans(beerD,centers=i)$withinss)}

# plot wss
plot(wss,type="b")

# pick what you think is the best number of clusters; this will be subjective
#rerun kmeans using the your choice for number of clusters and assign to object following the code in the next comment
beerKM<-kmeans(beerD,centers=5)
#assign the cluster numbers to a new variable in the original data
beer$KMSegment<-beerKM$cluster

#calculate the *unscaled* means for your clusters with the aggregate() function: 
aggregate(beer[c("abv","ibu")],by=list(KMSegment=beer$KMSegment), mean)
