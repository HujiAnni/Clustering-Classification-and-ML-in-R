AutoData <-read.table(file="AutoData.csv", header=TRUE,sep=",")
head(AutoData)
AutoDataS<-scale(AutoData[-1])
AutoDist<-dist(AutoDataS,method = "euclidean", diag = FALSE)
AutoCluster<-hclust(AutoDist,method="complete")
plot(AutoCluster)
CutTree<-cutree(AutoCluster,2)
AutoData$Segment<-CutTree
View(AutoData)
CutTree<-cutree(AutoCluster,4)
AutoData$Segment4<-CutTree
View(AutoData)
