library(readr)
beer <- read_csv("beer.csv")
# this activity is designed for you to compare and contrast the clusters created
#by k means with those created by HC
# the data is loaded, make sure abv and ibu are doubles
head(beer)

#as in activity 1, scale the data,.e.g. beerD<-data.frame(scale(beer[,c(1,2)]))
beerD<-data.frame(scale(beer[,c(1,2)]))

# REDO K MEANS
# runs k means with the same number of clusters in Activity 1
# beerKM<-kmeans(beerD,....)
beerKM<-kmeans(beerD,centers=2)

# add the segments back to unscaled data
beer$KMSegment<-beerKM$cluster
 
#REDO HC
# calculate distance matrix, assign to beerDist, i.e. beerDist<-dist()
beerDist<-dist(beerD,method = "euclidean", diag = FALSE)

#run hclust() and assign to beerHC, i.e. beerHC<-hclust()
beerHC<-hclust(beerDist,method="complete")
plot(beerHC)

# add the segments from HC back to the original data, creating thesame # of segments you used in the k means analysis
# i.e. beer$HCSegment<-cutree(beerHC,)
beer$HCSegment<-cutree(beerHC,2)

# use the table function to compare the size of the segments, i.e
table(beer$HCSegment,beer$KMSegment) 
 
# use the aggregate function to compare the means of the segments under both clustering forms
aggregate(beer[c("abv","ibu")],by=list(HCSegment=beer$HCSegment), mean)
aggregate(beer[c("abv","ibu")],by=list(KMSegment=beer$KMSegment), mean)
