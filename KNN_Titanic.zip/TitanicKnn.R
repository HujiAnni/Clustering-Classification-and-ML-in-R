# Ensure needed libraries are loaded.
library(readr)
library(class)
library(caTools)
#load data into the object boat:
boat<- read_csv("titanic.csv")
# have a quick look at data with head()
head(boat)
#remove any variables from boat that you won’t use for your classification
#the following code uses Survived, Sex, Age, SibSp, and Parch 
# You can use your choice of variables, or fewer variables if you wish
boat<-boat[,c(2,5,6,7,8)]


# knn() cannot work with missing variables, so for any variables you choose,
# check to see if there are missing variables If missing variables exist, either:
# 1) don't use that variable, or 
# 2) use only complete cases, or 
# 3) replace missing values with another value that makes sense.
summary(boat)

#below is an example for checking the variable Age for missing variables and replacing them with the mean Age.
#sum(is.na(boat$Age))
#boat<-within(boat,Age[is.na(Age)]<-mean(Age,na.rm=TRUE))
sum(is.na(boat$Age))
boat$AgeAVG<-boat$Age
boat<-within(boat,AgeAVG[is.na(Age)]<-mean(boat$Age,na.rm=TRUE))
boat$Age<-boat$AgeAVG
boat<-boat[,c(1,2,3,4,5)]
#View(boat)

# also note that the knn() function only works with numbers, so you need to replace characters with numbers
# here is example for replacing male and female in the variable Sex with the numbers 0 and 1
boat$Sex[boat$Sex=="male"]<-1
boat$Sex[boat$Sex=="female"]<-0


#set random seed to ensure that when your instructor runs your code they will get the same output you did. 
set.seed(123) 
#use the sample() function to split the data into 80% train, 20% test
sample<-sample.split(boat$Survived, SplitRatio = .80)
train<-subset(boat, sample == TRUE)
test<-subset(boat, sample == FALSE)

#use the knn() function to predict survival on the titanic
# try with 3 neighbors
knn3<-knn(train[-1],test[-1],train$Survived,k=3)
knn3

#use the table function to calculate the precision of your predictions
CF3<-table(knn3,test$Survived)
CF3
Precision3<-CF3[2,2]/(CF3[2,1]+CF3[2,2])
Precision3



# rerun knn  but with 5 neighbors, recalculate the precision
knn5<-knn(train[-1],test[-1],train$Survived,k=5)
knn5

#use the table function to calculate the precision of your predictions
CF5<-table(knn5,test$Survived)
CF5
Precision5<-CF5[2,2]/(CF5[2,1]+CF5[2,2])
Precision5
