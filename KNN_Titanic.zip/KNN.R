library(readr)
library(class)
library(caTools)
ERdr <- read_csv("EasyReadersData.csv")
head(ERdr)
set.seed(1) 
sample<-sample.split(ERdr$Buy, SplitRatio = .80)
train<-subset(ERdr, sample == TRUE)
test<-subset(ERdr, sample == FALSE)
knn1<-knn(train[-1],test[-1],train$Buy,k=1)
knn1
CF<-table(knn1,test$Buy)
CF
Precision<-CF[2,2]/(CF[2,1]+CF[2,2])
Precision


