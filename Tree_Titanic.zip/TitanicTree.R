# Ensure needed libraries are loaded
library(readr)
library(class)
library(caTools)
library(tree)
# load data into the objet boat:
boat<- read_csv("titanic.csv")
# have a quick look at data with head()
head(boat)
#remove any variables that you won’t use for your classification
#the following code uses Survived, Sex, Age, SibSp, and Parch
# You can use your choice of variables, or fewer variables if you wish
boat<-boat[,c(2,5,6,7,8)]
#cast the classification variable as a factor
boat$Survived<-as.factor(boat$Survived)

# the tree() function can not work with missing variables, so for any variables you choose, so for any variables you choose,
summary(boat)

#below is an example for checking the variable Age for missing variables and replacing them with the mean Age.
#sum(is.na(boat$Age))
#boat<-within(boat,Age[is.na(Age)]<-mean(Age,na.rm=TRUE))
sum(is.na(boat$Age))
boat$AgeAVG<-boat$Age
boat<-within(boat,AgeAVG[is.na(Age)]<-mean(boat$Age,na.rm=TRUE))
boat$Age<-boat$AgeAVG
boat<-boat[,c(1,2,3,4,5)]
boat$Sex[boat$Sex=="male"]<-1
boat$Sex[boat$Sex=="female"]<-0
summary(boat)


#set random seed to ensure that when your instructor runs your code they will get the same output you did. 
set.seed(123) 
#use the sample() function to split data into 80% train, 20% test
sample<-sample.split(boat$Survived, SplitRatio = .80)
train<-subset(boat, sample == TRUE)
test<-subset(boat, sample == FALSE)

#use the tree() function to predict survival on the titanic
#assign the tree to the TrainTree object
#i.e. TrainTree<-tree(Survived~variables of your choice, data=train)
# try with at least 2 attributes
TrainTree <- tree(Survived ~ Sex+Age+SibSp+Parch, data=train)

#plot and visualize your tree
plot(TrainTree)
text(TrainTree, cex=.5)
summary(TrainTree)

#use the predict function to see how well your model performs on the test subset
PredSurv <- predict(TrainTree, test, type="class")


CF<-table(test$Survived,PredSurv)
CF
Precision<-CF[2,2]/(CF[2,1]+CF[2,2])
Precision
