library(readr)
beer <- read_csv("beer.csv")
# check variable types, make sure abv and ibu are doubles, recast as necessary
head(beer)

#the following line should be similar to one you used in the last activity
# it sets up new scaled data frame with only the variables we need
beerD<-data.frame(scale(beer[c(1,2)]))

# use the dist() function to calculate euclidean distances between beers, and
# assign the result to the object beerDist.
beerDist<-dist(beerD,method = "euclidean", diag = FALSE)

#use hclust to perform clustering on beerDist, assign to beerHC
beerHC<-hclust(beerDist,method="complete")
plot(beerHC)

#cut the tree using cutree(), cut the tree to the same number of clusters you
# used in the k means activity, assign the segments to the original beer data frame
# i.e. use beer$HCSegment<-cutree()
CutTree<-cutree(beerHC,2)
beer$HCSegment<-CutTree
View(beer)

#generate cluster means for abv and ibu using the aggregate() function
aggregate(beer[c("abv","ibu")],by=list(KMSegment=beer$HCSegment), mean)
